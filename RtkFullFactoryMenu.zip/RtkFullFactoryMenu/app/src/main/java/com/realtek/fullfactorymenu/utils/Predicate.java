package com.realtek.fullfactorymenu.utils;

public interface Predicate<T> {

    boolean apply(T t);

}